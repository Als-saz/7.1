package com.example.demo.controllers;

import com.example.demo.model.Pet;
import com.example.demo.repo.PetRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/pets")
public class PetController {
    private final PetRepository repo;

    public PetController(PetRepository repo) { this.repo = repo; }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("pets", repo.findAll());
        return "pets/list";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("pet", new Pet());
        model.addAttribute("title", "Добавить питомца");
        return "pets/form";
    }

    @PostMapping
    public String create(@Valid @ModelAttribute("pet") Pet pet,
                         BindingResult errors,
                         RedirectAttributes ra) {
        if (errors.hasErrors()) return "pets/form";
        repo.save(pet);
        ra.addFlashAttribute("msg", "Питомец добавлен");
        return "redirect:/pets";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, Model model) {
        Pet pet = repo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Не найден id=" + id));
        model.addAttribute("pet", pet);
        model.addAttribute("title", "Редактировать питомца");
        return "pets/form";
    }

    @PostMapping("/{id}")
    public String update(@PathVariable Long id,
                         @Valid @ModelAttribute("pet") Pet pet,
                         BindingResult errors,
                         RedirectAttributes ra) {
        if (errors.hasErrors()) return "pets/form";
        pet.setId(id);
        repo.save(pet);
        ra.addFlashAttribute("msg", "Изменения сохранены");
        return "redirect:/pets";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes ra) {
        repo.deleteById(id);
        ra.addFlashAttribute("msg", "Запись удалена");
        return "redirect:/pets";
    }
}