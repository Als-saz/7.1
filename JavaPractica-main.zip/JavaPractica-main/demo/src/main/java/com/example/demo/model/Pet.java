package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "pets")
public class Pet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String owner_name;

    @Column(nullable = false)
    private String pet_name;

    @Column(nullable = false)
    private String species;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getOwnerName() { return owner_name; }
    public void setOwnerName(String owner_name) { this.owner_name = owner_name; }
    public String getPetName() { return pet_name; }
    public void setPetName(String pet_name) { this.pet_name = pet_name; }
    public String getSpecies() { return species; }
    public void setSpecies(String species) { this.species = species; }
}
