package org.example.calculator.config;

public class Config {
    public static final String DB_URL = "jdbc:mysql://localhost:3306/";
    public static final String DB_USER= "root";
    public static final String DB_PASSWORD= "root";
    public static final String DB_NAME= "calculator";
}
